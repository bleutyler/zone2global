You need Sphinx too build this documentation. Or you can read it in ASCII. ;)

Better run:

# pip sphinx

and once Sphinx is installed on your system, run:

$ make html

To build a copy of HTML'ed PySNMP documentation.
