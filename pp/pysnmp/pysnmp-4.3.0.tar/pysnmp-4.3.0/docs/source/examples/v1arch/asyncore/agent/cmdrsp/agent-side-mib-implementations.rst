.. toctree::
   :maxdepth: 2

Agent-side MIB implementations
------------------------------

.. include:: /../../examples/v1arch/asyncore/agent/cmdrsp/implementing-scalar-mib-objects.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/v1arch/asyncore/agent/cmdrsp/implementing-scalar-mib-objects.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/v1arch/asyncore/agent/cmdrsp/implementing-scalar-mib-objects.py>` script.


See also: :doc:`library reference </docs/contents>`.
