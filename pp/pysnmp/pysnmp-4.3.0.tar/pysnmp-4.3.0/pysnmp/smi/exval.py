from pysnmp.proto import rfc1905

noSuchObject = rfc1905.noSuchObject
noSuchInstance = rfc1905.noSuchInstance
endOfMibView = endOfMib = rfc1905.endOfMibView

