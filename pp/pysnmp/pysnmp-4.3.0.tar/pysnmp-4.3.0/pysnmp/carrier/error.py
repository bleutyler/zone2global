from pysnmp import error

class CarrierError(error.PySnmpError): pass
