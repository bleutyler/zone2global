# Obsolete, compatibility interface
from pysnmp.carrier.asyncore.dgram.udp import *
